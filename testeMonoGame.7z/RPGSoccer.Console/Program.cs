﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RPGSoccer.Dominio;
using RPGSoccer.Dominio.Dominio;

namespace RPGSoccer.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            new Partida();

        }
    }


}
