﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RPGSoccer.Dominio.Utils;

namespace RPGSoccer.Dominio.Parametros
{
    public class ParametrosPasse
    {
        public int JogadorDestino { get; set; }
        public AlturaPasse Altura { get; set; }
    }
}
